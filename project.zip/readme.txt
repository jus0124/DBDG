sql 쿼리와 관련된 코드는 모두 server.js에 있습니다
타 컴퓨터에서 동작할시 server.js의 connection의 수정과 sql 데이터베이스 필요
프론트엔드와 관련된 코드는 public 폴더안에 있습니다.